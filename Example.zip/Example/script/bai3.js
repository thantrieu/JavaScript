function showImage(src){
  document.getElementById('my_image').src = src;
}